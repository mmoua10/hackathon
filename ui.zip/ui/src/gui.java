import javax.swing.*;
import java.awt.*;

public class gui {
    public static void main(String[] args) {
        // Create a new JFrame
        JFrame frame = new JFrame();

        // Set the size of the frame
        frame.setSize(400, 300);

        // Set the default close operation
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a new JPanel with BorderLayout
        JPanel panel = new JPanel(new BorderLayout());

        // Set the background color to blue
        panel.setBackground(Color.BLUE);

        // Create a new JLabel with the title
        JLabel titleLabel = new JLabel("Car Maintenance");
        titleLabel.setForeground(Color.WHITE); // Set font color to white
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center align text

        // Change font size and style
        Font font = new Font("Arial", Font.BOLD, 24); // Change font family, style, and size
        titleLabel.setFont(font); // Apply the new font

        // Add the title label to the panel at the top
        panel.add(titleLabel, BorderLayout.NORTH);

        // Create a new JPanel for the buttons with GridLayout
        JPanel buttonPanel = new JPanel(new GridLayout(5, 2, 10, 10)); // 5 rows, 2 columns, 10 horizontal and vertical gap

        // Create buttons for car make and model, mileage, oil health, and tire health
        JButton makeModelButton = new JButton("Car Make and Model");
        JButton mileageButton = new JButton("Mileage");
        JButton oilHealthButton = new JButton("Oil Health");
        JButton tireHealthButton = new JButton("Tire Health");

        // Add buttons to the button panel
        buttonPanel.add(makeModelButton);
        buttonPanel.add(mileageButton);
        buttonPanel.add(oilHealthButton);
        buttonPanel.add(tireHealthButton);

        // Add the button panel to the center of the main panel
        panel.add(buttonPanel, BorderLayout.CENTER);

        // Add the panel to the frame
        frame.add(panel);

        // Set the frame to be visible
        frame.setVisible(true);
    }
}
