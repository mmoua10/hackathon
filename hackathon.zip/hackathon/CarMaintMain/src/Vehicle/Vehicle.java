package Vehicle;

public class Vehicle {
    /**
     *The constructor that creates a Vehicle based on the model and the year
     */
    private String model;
    private int year;
    private int oilMileage;
    private String batteryDate;
    private int tireMileage;
    private String windshieldDate;


    /**
     * Constructs a vehicle
     * @param model
     * @param year
     */
    public Vehicle(String model, int year, int oilMileage, int tireMileage, String batteryDate, String windshieldDate) {
        if(model == null || model.isEmpty()) {
            throw new IllegalArgumentException("Model is null");
        }
        if(year <= 0) {
            throw new IllegalArgumentException("Year is less than or equal to zero");
        }

        this.model = model;
        this.year = year;
        this.oilMileage = oilMileage;
        this.batteryDate = batteryDate;
        this.tireMileage = tireMileage;
        this.windshieldDate = windshieldDate;
    }//end of Vehicle constructor



    /**
     * Retrieves the date of when the oil was last changed
     *
     * @return a String representing the date of the last oil change on this vehicle
     */
    public int getOilMileage() {
        return oilMileage;
    }

    public int static getYear() {
        return year;
    }

    public int getTireMileage() {
        return tireMileage;
    }

    public String getBatteryDate() {
        return batteryDate;
    }

    public String getWindshieldDate() {
        return windshieldDate;
    }

    /**
     * Calculates and returns the time when the oil should be changed again based on how many miles driven in a day.
     * @return an integer representing the miles divided by 30
     */
    public int oilCalc() {
        return 5000/oilMileage;
    }//end oilCalc

    /**
     *  Calculates and returns the time when the tire should be rotated again based on how many miles driven in a day.
     * @return an integer representing
     */
    public int tireCalc() {
        return 5000/tireMileage;
    } //end tireCalc

    public String oilRecommended() {
        return "Oil recommended date: " + oilCalc();
    }

    public String tireRecommend() {
        return "Tire recommend date: " + tireCalc();
    }
}
