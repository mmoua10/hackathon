

import java.sql.SQLOutput;
import java.util.Scanner;
import CarMainTMethods.*;
import Vehicle.*;

import static CarMainTMethods.CarMainTMethods.*;


public class Main {
    public static void main(String[] args) throws Exception {

        Scanner fin = new Scanner(System.in);
        Scanner kb = new Scanner(System.in); // New scanner for keyboard input
        int choice;

        Vehicle[] myVehicle = null;
        myVehicle = new Vehicle[]{fillArray(kb)};

        do {
            choice = CarMainTMethods.menu(kb); // Passing the keyboard scanner to the menu method
            switch (choice) {
                case 1:
                    for (Vehicle vehicle : myVehicle) {
                        System.out.println(vehicle.oilRecommended());
                    }
                    break;
                case 2:
                    for (Vehicle vehicle : myVehicle) {
                        System.out.println(vehicle.tireRecommend());
                    }
                    break;
                case 3:
                    int year = Vehicle.getYear();
                    CarMainTMethods.batteryService(year);
                    break;
                case 4:
                    System.out.println("Recommended to change windshield wiper fluid regularly.");

                    break;
                case 5:
                    System.out.println("Program Ending");
                    break;
            }//end choice
        } while (choice != 5);
    }// end main
}