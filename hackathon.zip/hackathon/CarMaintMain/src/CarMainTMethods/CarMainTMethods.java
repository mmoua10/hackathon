package CarMainTMethods;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Scanner;
import Vehicle.*;

public class CarMainTMethods {
    public static int menu(final Scanner kb) {
    if (kb == null) {
        throw new IllegalArgumentException("bad scanner menu");
    }

    int choice;
    do {
        System.out.println("Please choose from the following");
        System.out.println("1) Future oil service date");
        System.out.println("2) Future tires service date");
        System.out.println("3) Future battery service date");
        System.out.println("4) Future windshield fluid service date");
        System.out.println("5) Quit");
        System.out.print("Choice --> ");
        choice = Integer.parseInt(kb.nextLine());
        System.out.println();
    } while (choice < 1 || choice > 5);

    return choice;
}

    public static Vehicle fillArray(Scanner kb) {
        if (kb == null) {
            throw new IllegalArgumentException("kb is null");
        }
        String model = readString("car model", kb);
        int year = Integer.parseInt(readString("year", kb));
        int oilMileage = Integer.parseInt(readString("oil mileage", kb));
        int tireMileage = Integer.parseInt(readString("tire mileage", kb));
        String batteryDate = readString("battery date", kb);
        String windshieldDate = readString("windshield date", kb);


        return new Vehicle(model, year, oilMileage, tireMileage, batteryDate, windshieldDate);
    }//end fillArray

    /**
     * The readOutputFilename calls the readString to read a output filename
     *
     * @param kb Representing the Scanner object to the keyboard
     * @return String Representing the output filename
     *
     * @throws IllegalArgumentException if kb is null
     *
     * @NOTE You must ensure the input buffer is empty at the end of the method
     */
    public static String readOutputFilename(final Scanner kb) {
        if(kb == null)
            throw new IllegalArgumentException("Bad param readOutputFilename");

        return readString("output filename",kb);
    }


    /**
     * The readString reads a string from the keyboard and ensures the string is not null or empty
     *
     * @param type Representing a String for the prompt on what to enter
     * @param kb Representing the Scanner object to the keyboard
     * @return String Representing the appropriate String
     *
     * @throws IllegalArgumentException if kb is null
     *
     * @NOTE You must ensure the input buffer is empty at the end of the method
     */
    private static String readString(final String type, final Scanner kb)
    {
        if(type == null || type.isEmpty() || kb == null)
            throw new IllegalArgumentException("Bad param readString");

        String str="";
        do
        {
            System.out.print("Please enter the " + type + " ");
            str = kb.nextLine().trim();
        }while(str == null || str.isEmpty());

        return str;
    }// end readString

    public static void batteryService(int year) {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int batteryAge = currentYear - year;

        if (batteryAge >= 2) {
            System.out.println("Your vehicle's battery is " + batteryAge + " years old.");
            System.out.println("It's recommended to replace the battery every two years.");
            System.out.println("Consider replacing the battery soon.");
        } else {
            System.out.println("Your vehicle's battery is still relatively new.");
            System.out.println("No immediate action required.");
        }
    }
}
